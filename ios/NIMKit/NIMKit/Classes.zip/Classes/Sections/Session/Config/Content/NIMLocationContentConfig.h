//
//  NIMLocationContentConfig.h
//  NIMKit
//
//  Created by amao on 9/15/15.
//  Copyright (c) 2015 NetEase. All rights reserved.
//

#import "NIMBaseSessionContentConfig.h"

@interface NIMLocationContentConfig : NSObject<NIMSessionContentConfig>

@end
