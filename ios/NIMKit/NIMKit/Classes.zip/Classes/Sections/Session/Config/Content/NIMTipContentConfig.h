//
//  NIMTipContentConfig.h
//  NIMKit
//
//  Created by chris on 16/1/21.
//  Copyright © 2016年 NetEase. All rights reserved.
//

#import "NIMBaseSessionContentConfig.h"

@interface NIMTipContentConfig : NSObject<NIMSessionContentConfig>

@end
