//
//  NIMSessionFileTransContentView.h
//  NIM
//
//  Created by chris on 15/4/21.
//  Copyright (c) 2015年 Netease. All rights reserved.
//

#import "NIMSessionMessageContentView.h"

@interface NIMSessionFileTransContentView : NIMSessionMessageContentView

@property (nonatomic,strong,readonly) UIImageView *imageView;

@end
