//
//  NIMSessionVideoContentView.h
//  NIMKit
//
//  Created by chris on 15/4/10.
//  Copyright (c) 2015年 Netease. All rights reserved.
//

#import "NIMSessionMessageContentView.h"

@interface NIMSessionVideoContentView : NIMSessionMessageContentView

@end
