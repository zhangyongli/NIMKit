//
//  NIMSessionNetChatNotifyContentView.h
//  NIMKit
//
//  Created by chris on 15/5/8.
//  Copyright (c) 2015年 Netease. All rights reserved.
//

#import "NIMSessionMessageContentView.h"
#import "NIMKitDependency.h"

@interface NIMSessionNetChatNotifyContentView : NIMSessionMessageContentView

@property (nonatomic, strong) M80AttributedLabel *textLabel;

@end
