//
//  NIMGrowingInternalTextView.h
//  NIMKit
//
//  Created by chris on 16/3/27.
//  Copyright © 2016年 Netease. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NIMGrowingInternalTextView : UITextView

@property (nonatomic,strong) NSAttributedString *placeholderAttributedText;

@end
