//
//  NIMTeamMemberCardHeaderCell.h
//  NIMKit
//
//  Created by chris on 16/5/10.
//  Copyright © 2016年 NetEase. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NIMCommonTableViewCell.h"

@interface NIMTeamMemberCardHeaderCell : UITableViewCell<NIMCommonTableViewCell>

@end
