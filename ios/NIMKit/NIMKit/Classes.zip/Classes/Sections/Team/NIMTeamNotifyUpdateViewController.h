//
//  NIMTeamNotifyUpdateViewController.h
//  NIMKit
//
//  Created by chris on 2017/9/20.
//  Copyright © 2017年 NetEase. All rights reserved.
//

#import <UIKit/UIKit.h>

@class NIMTeam;

@interface NIMTeamNotifyUpdateViewController : UIViewController

- (instancetype)initTeam:(NIMTeam *)team;

@end
