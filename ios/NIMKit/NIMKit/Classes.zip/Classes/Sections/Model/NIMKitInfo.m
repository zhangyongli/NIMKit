//
//  NIMKitInfo.m
//  NIMKit
//
//  Created by amao on 2016/11/17.
//  Copyright © 2016年 NetEase. All rights reserved.
//

#import "NIMKitInfo.h"

@implementation NIMKitInfo

@end
