//
//  UITableView+NTESScrollToBottom.h
//  NIMDemo
//
//  Created by chris.
//  Copyright (c) 2015年 Netease. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableView (NIMKit)

- (void)nim_scrollToBottom:(BOOL)animation;
@end
