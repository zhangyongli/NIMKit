//
//  M80AttributedLabel+NIMKit.h
//  NIM
//
//  Created by chris.
//  Copyright (c) 2015 Netease. All rights reserved.
//

#import "NIMKitDependency.h"

@interface M80AttributedLabel (NIMKit)
- (void)nim_setText:(NSString *)text;
@end
