//
//  NIMKitIndependentModeExtraInfo.m
//  NIMKit
//
//  Created by chris on 2017/10/10.
//  Copyright © 2017年 NetEase. All rights reserved.
//

#import "NIMKitIndependentModeExtraInfo.h"

@implementation NIMKitIndependentModeExtraInfo

@end
