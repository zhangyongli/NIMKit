//
//  NIMKitDataProviderImpl.h
//  NIMKit
//
//  Created by chris on 2016/10/31.
//  Copyright © 2016年 NetEase. All rights reserved.
//

#import "NIMKitDataProvider.h"

@interface NIMKitDataProviderImpl : NSObject<NIMKitDataProvider>

@end
